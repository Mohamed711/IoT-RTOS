/*
 * MAIN.c
 *
 * Created: 2/2/2016 11:41:39 PM
 *  Author: Karen-pc
 */ 
#include <avr/io.h>
#include "DIO.h"
#include "WATCHDOG.h"
#include "WATCHDOG_CFG.h"
#include <avr/delay.h>

int main(void)
{
	WDT_Enable(WDT_1S);
	DIO_InitPortDirection(PB,0xF0,0xF0);
	DIO_WritePort(PB, 0xF0,0x00);
	while(1)
	{
	//DIO_WritePort(u8 PortName,u8 PortData,u8 PortMask);
	DIO_WritePort(PB,0xFF,0xF0);
	_delay_ms(900);
	DIO_WritePort(PB, 0x00,0xF0);
	_delay_ms(9000);
	//WDT_Disable();
	}
}